const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const signupRoute = require('./api/routes/signup');
const loginRoute = require('./api/routes/login');
const accountRoute = require('./api/routes/account');

// Initialize environment variables
dotenv.config();

// Initialize Express app
const app = express();

// Middleware to handle CORS
app.use(cors({
  origin: 'https://jokercreation.netlify.app',  // Allowing requests from your Netlify frontend URL
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(express.json()); // To parse incoming JSON requests

// MongoDB connection
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected successfully!'))
  .catch(err => console.log('MongoDB connection error:', err));

// Use the route files
app.use('/signup', signupRoute);
app.use('/login', loginRoute);
app.use('/account', accountRoute);

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
