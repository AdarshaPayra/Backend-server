require('dotenv').config(); // Loads environment variables from .env file

const express = require('express');
const mongoose = require('mongoose');
const app = express();

// Middleware to parse incoming requests with JSON payloads
app.use(express.json());

// Mongo URI from environment variables
const mongoURI = process.env.MONGO_URI;

// Check if Mongo URI exists
if (!mongoURI) {
  console.error("Mongo URI not defined in .env file!");
  process.exit(1); // Exit the process with failure code
}

// MongoDB connection
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('MongoDB connected successfully');
  })
  .catch((error) => {
    console.error('MongoDB connection error:', error);
  });

// Sample route (this will be used for login/signup functionality)
const userRoutes = require('./routes/userRoutes'); // Define user routes in a separate file
app.use('/api/users', userRoutes); // All user-related routes are prefixed with /api/users

// Server listening on port 5000
app.listen(5000, () => {
  console.log("Server running on port 5000");
});
