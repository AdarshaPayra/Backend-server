const mongoose = require('mongoose');
const crypto = require('crypto');

const secretSchema = new mongoose.Schema({
  key: {
    type: String,
    required: true
  },
  value: {
    type: String,
    required: true
  }
});

// Encrypt secret before saving
secretSchema.pre('save', function(next) {
  if (this.isModified('value') || this.isNew) {
    const algorithm = 'aes-256-ctr';  // Encryption algorithm
    const secretKey = process.env.JWT_SECRET;  // Encryption key (secure this)
    const iv = crypto.randomBytes(16);  // Random initialization vector for each encryption

    const cipher = crypto.createCipheriv(algorithm, Buffer.from(secretKey, 'hex'), iv);
    let encrypted = cipher.update(this.value, 'utf-8', 'hex');
    encrypted += cipher.final('hex');

    this.value = `${iv.toString('hex')}:${encrypted}`;  // Store both IV and encrypted value
  }
  next();
});

// Decrypt secret when retrieving from DB
secretSchema.methods.decrypt = function() {
  const [ivHex, encryptedValue] = this.value.split(':');
  const iv = Buffer.from(ivHex, 'hex');
  const algorithm = 'aes-256-ctr';
  const secretKey = process.env.JWT_SECRET;  // Encryption key

  const decipher = crypto.createDecipheriv(algorithm, Buffer.from(secretKey, 'hex'), iv);
  let decrypted = decipher.update(encryptedValue, 'hex', 'utf-8');
  decrypted += decipher.final('utf-8');

  return decrypted;
};

module.exports = mongoose.model('Secret', secretSchema);
